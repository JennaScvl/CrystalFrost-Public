message_template.msg differes from the official Linden Lab viewer source code.

When updating from the official viewer, copy the file over, and than apply
patches in *.patch files.
