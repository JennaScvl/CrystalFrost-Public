namespace OpenMetaverse.TestClient_
{
    public class SitOnCommand : Command
    {
        public SitOnCommand(TestClient testClient)
        {
            Name = "siton";
            Description = "Attempt to sit on a particular prim, with specified UUID";
            Category = CommandCategory.Movement;
        }

        public override string Execute(string[] args, UUID fromAgentID)
        {
            if (args.Length != 1)
                return "Usage: siton UUID";

            UUID target;

            if (UUID.TryParse(args[0], out target))
            {
                Primitive targetPrim = Client.Network.CurrentSim.ObjectsPrimitives.Find(
                    prim => prim.ID == target
                );

                if (targetPrim != null)
                {
                    Client.Self.RequestSit(targetPrim.ID, OMVVector3.Zero);
                    Client.Self.Sit();
                    return "Requested to sit on prim " + targetPrim.ID +
                        " (" + targetPrim.LocalID + ")";
                }
            }

            return "Couldn't find a prim to sit on with UUID " + args[0];
        }
    }
}
